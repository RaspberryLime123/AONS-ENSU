BEFORE YOU DO *ANYTHING* READ THIS!
This .bat file relies on all the contents of "AONS-ENSUv2.0" to work.
If you move anything, anything at all, it won't work. If you move something on accident and can't fix the problems it causes,
just reinstall the whole thing.






This is a batch file meant for automatically updating ONScripter-EN executables to the (almost) most recent version, 
while also creating an ons.cfg and using it create a save folder.


DEPENDENCIES: unzip.exe (included in AONS-ENSUv2.0)


NOTE: user-set variables are declared and initialized "set /p <VAR> = <VALUE>"


VARIABLES AND THEIR PURPOSES

WD
As the .bat tells you, this is the full path of the game directory. 
Game directory means the folder where the game you want to update is. 
IT IS IMPORTANT TO NOTE: when entering a path for WD, do not add a trailing backslash. If you do, it will mess up the ons.cfg
and the savedata folder won't work. The daves won't appear in "savedata" and you will be frustrated looking for them.



ONS-N 
corresponds to the exact file name, including extension, of the updated ONScripter-EN zip file. 
The value of ONS-N *MUST* be exactly the same as the .zip file that contains the updating resources.
This variable is name of the file that 7zip will unzip, and it is used in the command that calls 7zip.
This is file is included in AONS-ENSUv2.0 folder, 
and the variable matches the exact name of the file that came with the folder.

ONS-D
deprecated in favor of "parent" in v2.0

parent
corresponds to the folder in which the file AONS-ENSUv2.0.bat is located in. This variable, and the way it is used,
is what makes it impossible to move/rename any of the components of this installation 



DEBUGGING

FILL OUT LATER

if you have problems you just can't figure out, have something to say, or want to talk visual novels, 
contact me at my business email: raspberrylime345@gmail.com